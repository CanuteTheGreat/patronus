//! Application state

use patronus_config::ConfigStore;
use patronus_firewall::RuleManager;
use std::sync::Arc;

/// Shared application state
#[derive(Clone)]
pub struct AppState {
    pub rule_manager: Arc<RuleManager>,
    pub config_store: Arc<ConfigStore>,
}

impl AppState {
    pub fn new(rule_manager: RuleManager, config_store: ConfigStore) -> Self {
        Self {
            rule_manager: Arc::new(rule_manager),
            config_store: Arc::new(config_store),
        }
    }
}
