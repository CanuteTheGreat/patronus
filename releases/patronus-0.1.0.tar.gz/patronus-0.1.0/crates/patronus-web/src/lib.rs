//! Patronus Web Interface
//!
//! Provides the web-based management interface for Patronus.

use axum::{
    routing::get,
    Router,
};
use std::net::SocketAddr;
use tower_http::services::ServeDir;

pub mod handlers;
pub mod state;

pub use state::AppState;

/// Create the web application router
pub fn create_app(state: AppState) -> Router {
    Router::new()
        .route("/", get(handlers::index))
        .route("/firewall", get(handlers::firewall_page))
        .route("/api/interfaces", get(handlers::list_interfaces))
        .route("/api/firewall/rules", get(handlers::list_firewall_rules))
        .with_state(state)
}

/// Start the web server
pub async fn serve(addr: SocketAddr, state: AppState) -> anyhow::Result<()> {
    let app = create_app(state);

    tracing::info!("Starting web server on {}", addr);

    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}
