//! Configuration Apply Engine
//!
//! This module handles applying declarative configurations to the running system.
//! It provides diff generation, dry-run simulation, atomic application, and rollback.
//!
//! Key features:
//! - Generate diff between current and desired state
//! - Dry-run mode (show changes without applying)
//! - Atomic apply (all-or-nothing)
//! - Automatic rollback on failure
//! - State history for manual rollback
//! - Dependency resolution and ordering

use chrono::{DateTime, Utc};
use patronus_core::{Error, Result};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;

use crate::applier::{Applier, ApplierRegistry};
use crate::declarative::{ConfigParser, DeclarativeConfig, ResourceKind};
use crate::store::ConfigStore;
use std::sync::Arc;

/// Change operation type
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ChangeOp {
    Create,
    Update,
    Delete,
    NoChange,
}

/// A single configuration change
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfigChange {
    pub operation: ChangeOp,
    pub resource_kind: ResourceKind,
    pub resource_name: String,
    pub old_config: Option<DeclarativeConfig>,
    pub new_config: Option<DeclarativeConfig>,
    pub dependencies: Vec<String>, // Resources this depends on
}

/// Result of a diff operation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiffResult {
    pub changes: Vec<ConfigChange>,
    pub creates: usize,
    pub updates: usize,
    pub deletes: usize,
    pub no_changes: usize,
}

impl DiffResult {
    pub fn has_changes(&self) -> bool {
        self.creates > 0 || self.updates > 0 || self.deletes > 0
    }

    pub fn total_changes(&self) -> usize {
        self.creates + self.updates + self.deletes
    }
}

/// Apply result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApplyResult {
    pub success: bool,
    pub changes_applied: usize,
    pub changes_failed: usize,
    pub errors: Vec<String>,
    pub rollback_performed: bool,
}

/// Configuration snapshot for rollback
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfigSnapshot {
    pub id: String,
    pub timestamp: DateTime<Utc>,
    pub description: String,
    pub configs: Vec<DeclarativeConfig>,
}

/// Configuration state manager
pub struct StateManager {
    state_dir: PathBuf,
    current_state: HashMap<String, DeclarativeConfig>, // name -> config
    snapshots: Vec<ConfigSnapshot>,
}

impl StateManager {
    pub fn new(state_dir: PathBuf) -> Self {
        Self {
            state_dir,
            current_state: HashMap::new(),
            snapshots: Vec::new(),
        }
    }

    /// Initialize state manager and load current state
    pub async fn init(&mut self) -> Result<()> {
        // Create state directory if needed
        tokio::fs::create_dir_all(&self.state_dir).await?;

        // Load current state from disk
        self.load_current_state().await?;

        // Load snapshots
        self.load_snapshots().await?;

        Ok(())
    }

    async fn load_current_state(&mut self) -> Result<()> {
        let state_file = self.state_dir.join("current.yaml");

        if state_file.exists() {
            let content = tokio::fs::read_to_string(&state_file).await?;
            let configs = parse_state(&content)?;

            for config in configs {
                self.current_state
                    .insert(config.metadata.name.clone(), config);
            }

            tracing::info!(
                "Loaded {} resources from current state",
                self.current_state.len()
            );
        }

        Ok(())
    }

    /// Write the state as ONE YAML list (what [`parse_state`] and
    /// `ConfigParser::parse_yaml` read), sorted by name, atomically. It used
    /// to be written as `---`-separated single documents that the next
    /// process could not load ("expected a sequence"), so every GitOps run
    /// after the first failed at startup.
    async fn save_current_state(&self) -> Result<()> {
        let state_file = self.state_dir.join("current.yaml");
        let mut configs: Vec<&DeclarativeConfig> = self.current_state.values().collect();
        configs.sort_by(|a, b| a.metadata.name.cmp(&b.metadata.name));
        let yaml = serde_yaml::to_string(&configs)
            .map_err(|e| Error::Config(format!("serialize GitOps state: {e}")))?;
        let tmp = self.state_dir.join(".current.yaml.new");
        tokio::fs::write(&tmp, yaml).await?;
        tokio::fs::rename(&tmp, &state_file).await?;
        Ok(())
    }

    async fn load_snapshots(&mut self) -> Result<()> {
        let snapshots_dir = self.state_dir.join("snapshots");

        if !snapshots_dir.exists() {
            return Ok(());
        }

        let mut entries = tokio::fs::read_dir(&snapshots_dir).await?;

        while let Some(entry) = entries.next_entry().await? {
            let path = entry.path();

            if path.extension().and_then(|s| s.to_str()) == Some("yaml") {
                let content = tokio::fs::read_to_string(&path).await?;
                if let Ok(snapshot) = serde_yaml::from_str::<ConfigSnapshot>(&content) {
                    self.snapshots.push(snapshot);
                }
            }
        }

        // Sort by timestamp (newest first)
        self.snapshots
            .sort_by_key(|s| std::cmp::Reverse(s.timestamp));

        tracing::info!("Loaded {} snapshots", self.snapshots.len());

        Ok(())
    }

    /// Get current resource by name
    pub fn get(&self, name: &str) -> Option<&DeclarativeConfig> {
        self.current_state.get(name)
    }

    /// List all current resources
    pub fn list(&self) -> Vec<&DeclarativeConfig> {
        self.current_state.values().collect()
    }

    /// List resources of specific kind
    pub fn list_by_kind(&self, kind: &ResourceKind) -> Vec<&DeclarativeConfig> {
        self.current_state
            .values()
            .filter(|c| &c.kind == kind)
            .collect()
    }

    /// Update a resource
    fn update(&mut self, config: DeclarativeConfig) {
        self.current_state
            .insert(config.metadata.name.clone(), config);
    }

    /// Delete a resource
    fn delete(&mut self, name: &str) -> Option<DeclarativeConfig> {
        self.current_state.remove(name)
    }

    /// Create a snapshot of current state
    pub async fn create_snapshot(&mut self, description: String) -> Result<ConfigSnapshot> {
        let snapshot = ConfigSnapshot {
            id: uuid::Uuid::new_v4().to_string(),
            timestamp: Utc::now(),
            description,
            configs: self.current_state.values().cloned().collect(),
        };

        // Save to disk
        let snapshots_dir = self.state_dir.join("snapshots");
        tokio::fs::create_dir_all(&snapshots_dir).await?;

        let snapshot_file = snapshots_dir.join(format!("{}.yaml", snapshot.id));
        let yaml = serde_yaml::to_string(&snapshot)
            .map_err(|e| Error::Config(format!("Failed to serialize snapshot: {}", e)))?;

        tokio::fs::write(&snapshot_file, yaml).await?;

        self.snapshots.insert(0, snapshot.clone());

        // Keep only last 100 snapshots
        if self.snapshots.len() > 100 {
            if let Some(old) = self.snapshots.pop() {
                let old_file = snapshots_dir.join(format!("{}.yaml", old.id));
                tokio::fs::remove_file(&old_file).await.ok();
            }
        }

        tracing::info!("Created snapshot: {}", snapshot.id);

        Ok(snapshot)
    }

    /// Get list of snapshots
    pub fn list_snapshots(&self) -> &[ConfigSnapshot] {
        &self.snapshots
    }

    /// Get specific snapshot
    pub fn get_snapshot(&self, id: &str) -> Option<&ConfigSnapshot> {
        self.snapshots.iter().find(|s| s.id == id)
    }
}

/// Configuration apply engine
pub struct ApplyEngine {
    state_manager: StateManager,
    dry_run: bool,
    /// Where resources go: the config store plus the appliers that own each
    /// resource kind. Without a target, `apply` refuses to do anything
    /// (it used to log and report success while changing nothing).
    target: Option<(Arc<ConfigStore>, ApplierRegistry)>,
}

impl ApplyEngine {
    pub fn new(state_dir: PathBuf) -> Self {
        Self {
            state_manager: StateManager::new(state_dir),
            dry_run: false,
            target: None,
        }
    }

    /// Attach the store and appliers resources are dispatched to.
    pub fn with_target(mut self, store: Arc<ConfigStore>, registry: ApplierRegistry) -> Self {
        self.target = Some((store, registry));
        self
    }

    fn target(&self) -> Result<(&ConfigStore, &ApplierRegistry)> {
        self.target
            .as_ref()
            .map(|(s, r)| (s.as_ref(), r))
            .ok_or_else(|| {
                Error::Config(
                    "ApplyEngine has no config store/appliers attached (use with_target)"
                        .to_string(),
                )
            })
    }

    fn applier_for(&self, kind: &ResourceKind) -> Result<(&ConfigStore, Arc<dyn Applier>)> {
        let (store, registry) = self.target()?;
        let a = registry.for_kind(kind).ok_or_else(|| {
            Error::Config(format!(
                "no applier is registered for {kind:?} resources; they cannot be applied"
            ))
        })?;
        Ok((store, a))
    }

    pub async fn init(&mut self) -> Result<()> {
        self.state_manager.init().await
    }

    pub fn set_dry_run(&mut self, dry_run: bool) {
        self.dry_run = dry_run;
    }

    /// Generate diff between current and desired state
    pub fn diff(&self, desired_configs: &[DeclarativeConfig]) -> Result<DiffResult> {
        let mut changes = Vec::new();

        // Build map of desired configs
        let desired_map: HashMap<String, &DeclarativeConfig> = desired_configs
            .iter()
            .map(|c| (c.metadata.name.clone(), c))
            .collect();

        // Find creates and updates
        for (name, new_config) in &desired_map {
            if let Some(old_config) = self.state_manager.get(name) {
                // Resource exists - check if changed
                if self.has_changed(old_config, new_config) {
                    changes.push(ConfigChange {
                        operation: ChangeOp::Update,
                        resource_kind: new_config.kind.clone(),
                        resource_name: name.clone(),
                        old_config: Some(old_config.clone()),
                        new_config: Some((*new_config).clone()),
                        dependencies: self.get_dependencies(new_config),
                    });
                } else {
                    changes.push(ConfigChange {
                        operation: ChangeOp::NoChange,
                        resource_kind: new_config.kind.clone(),
                        resource_name: name.clone(),
                        old_config: Some(old_config.clone()),
                        new_config: Some((*new_config).clone()),
                        dependencies: Vec::new(),
                    });
                }
            } else {
                // New resource
                changes.push(ConfigChange {
                    operation: ChangeOp::Create,
                    resource_kind: new_config.kind.clone(),
                    resource_name: name.clone(),
                    old_config: None,
                    new_config: Some((*new_config).clone()),
                    dependencies: self.get_dependencies(new_config),
                });
            }
        }

        // Find deletes (resources in current but not in desired)
        for name in self.state_manager.current_state.keys() {
            if !desired_map.contains_key(name) {
                let old_config = self.state_manager.get(name).unwrap();
                changes.push(ConfigChange {
                    operation: ChangeOp::Delete,
                    resource_kind: old_config.kind.clone(),
                    resource_name: name.clone(),
                    old_config: Some(old_config.clone()),
                    new_config: None,
                    dependencies: Vec::new(),
                });
            }
        }

        // Sort changes by dependency order
        changes = self.sort_by_dependencies(changes)?;

        // Count operations
        let creates = changes
            .iter()
            .filter(|c| c.operation == ChangeOp::Create)
            .count();
        let updates = changes
            .iter()
            .filter(|c| c.operation == ChangeOp::Update)
            .count();
        let deletes = changes
            .iter()
            .filter(|c| c.operation == ChangeOp::Delete)
            .count();
        let no_changes = changes
            .iter()
            .filter(|c| c.operation == ChangeOp::NoChange)
            .count();

        Ok(DiffResult {
            changes,
            creates,
            updates,
            deletes,
            no_changes,
        })
    }

    fn has_changed(&self, old: &DeclarativeConfig, new: &DeclarativeConfig) -> bool {
        // Simple comparison - serialize and compare
        // In production, would do smarter comparison
        let old_yaml = ConfigParser::to_yaml(old).unwrap_or_default();
        let new_yaml = ConfigParser::to_yaml(new).unwrap_or_default();
        old_yaml != new_yaml
    }

    fn get_dependencies(&self, _config: &DeclarativeConfig) -> Vec<String> {
        // Extract dependency names from config
        // For example, firewall rules might depend on aliases or interfaces
        // This is simplified - real implementation would parse spec
        Vec::new()
    }

    fn sort_by_dependencies(&self, mut changes: Vec<ConfigChange>) -> Result<Vec<ConfigChange>> {
        // Create before Update before Delete. Within that, what others refer
        // to comes first when something is made (aliases before the rules
        // naming them, groups before the users in them) and last when it is
        // removed (a rule goes before the alias it used).
        let op = |c: &ConfigChange| match c.operation {
            ChangeOp::Create => 0,
            ChangeOp::Update => 1,
            ChangeOp::Delete => 2,
            ChangeOp::NoChange => 3,
        };
        let referred =
            |c: &ConfigChange| matches!(c.resource_kind, ResourceKind::Alias | ResourceKind::Group);
        changes.sort_by_key(|c| {
            let kind_rank = match (c.operation == ChangeOp::Delete, referred(c)) {
                (false, true) => 0,
                (false, false) => 1,
                (true, false) => 0,
                (true, true) => 1,
            };
            (op(c), kind_rank)
        });
        Ok(changes)
    }

    /// Apply configuration changes
    pub async fn apply(&mut self, desired_configs: Vec<DeclarativeConfig>) -> Result<ApplyResult> {
        // Generate diff
        let diff = self.diff(&desired_configs)?;

        if !diff.has_changes() {
            tracing::info!("No changes to apply");
            return Ok(ApplyResult {
                success: true,
                changes_applied: 0,
                changes_failed: 0,
                errors: Vec::new(),
                rollback_performed: false,
            });
        }

        if self.dry_run {
            tracing::info!("Dry-run mode: would apply {} changes", diff.total_changes());
            return Ok(ApplyResult {
                success: true,
                changes_applied: 0,
                changes_failed: 0,
                errors: vec!["Dry-run mode - no changes applied".to_string()],
                rollback_performed: false,
            });
        }

        // Refuse up front (before touching anything) if some resource kind
        // has no applier.
        for change in &diff.changes {
            if change.operation != ChangeOp::NoChange {
                self.applier_for(&change.resource_kind)?;
            }
        }
        let (store_arc, _) = self.target.clone().ok_or_else(|| {
            Error::Config("ApplyEngine has no config store/appliers attached".to_string())
        })?;
        let store = store_arc.as_ref();
        let store_revision = store.snapshot("gitops", "before declarative apply").await?;

        // Create snapshot before applying
        let snapshot = self
            .state_manager
            .create_snapshot("Pre-apply snapshot".to_string())
            .await?;

        tracing::info!(
            "Applying {} changes (snapshot: {})",
            diff.total_changes(),
            snapshot.id
        );

        let mut changes_applied = 0;
        let mut changes_failed = 0;
        let mut errors = Vec::new();

        // Apply changes in order
        for change in &diff.changes {
            if change.operation == ChangeOp::NoChange {
                continue;
            }

            match self.apply_change(change).await {
                Ok(_) => {
                    changes_applied += 1;
                    tracing::info!("Applied {:?} {}", change.operation, change.resource_name);
                }
                Err(e) => {
                    changes_failed += 1;
                    let error_msg = format!(
                        "Failed to apply {:?} {}: {}",
                        change.operation, change.resource_name, e
                    );
                    tracing::error!("{}", error_msg);
                    errors.push(error_msg);

                    // Rollback on first error: nothing has been pushed to
                    // the system yet, so restoring the store is enough.
                    tracing::warn!("Rolling back to snapshot {}", snapshot.id);
                    let rolled_back = self.restore_store(store_revision).await;
                    if let Err(rollback_err) = &rolled_back {
                        errors.push(format!("Rollback failed: {}", rollback_err));
                    }
                    self.state_manager = {
                        let mut sm = StateManager::new(self.state_manager.state_dir.clone());
                        sm.init().await?;
                        sm
                    };
                    return Ok(ApplyResult {
                        success: false,
                        changes_applied,
                        changes_failed,
                        errors,
                        rollback_performed: rolled_back.is_ok(),
                    });
                }
            }
        }

        // Push the new store state to the system: each affected applier
        // once, in phase order. On failure restore the store and re-apply
        // the old state so the system and the store agree again.
        let mut touched: Vec<Arc<dyn Applier>> = Vec::new();
        for change in &diff.changes {
            if change.operation == ChangeOp::NoChange {
                continue;
            }
            let (_, a) = self.applier_for(&change.resource_kind)?;
            if !touched.iter().any(|t| t.name() == a.name()) {
                touched.push(a);
            }
        }
        touched.sort_by_key(|a| a.phase());
        for a in &touched {
            if let Err(e) = a.apply(store).await {
                errors.push(format!("{} failed to apply: {e}", a.name()));
                let restored = self.restore_store(store_revision).await;
                for b in &touched {
                    if let Err(e2) = b.apply(store).await {
                        errors.push(format!(
                            "{} failed to re-apply the old state: {e2}",
                            b.name()
                        ));
                    }
                }
                return Ok(ApplyResult {
                    success: false,
                    changes_applied,
                    changes_failed: changes_failed + 1,
                    errors,
                    rollback_performed: restored.is_ok(),
                });
            }
        }

        // Save new state
        self.state_manager.save_current_state().await?;

        tracing::info!("Successfully applied {} changes", changes_applied);

        Ok(ApplyResult {
            success: true,
            changes_applied,
            changes_failed,
            errors,
            rollback_performed: false,
        })
    }

    async fn apply_change(&mut self, change: &ConfigChange) -> Result<()> {
        match change.operation {
            ChangeOp::Create => {
                let config = change
                    .new_config
                    .as_ref()
                    .ok_or_else(|| Error::Config("No new config for create".to_string()))?;

                // Apply the resource creation based on kind
                self.create_resource(config).await?;

                // Update state
                self.state_manager.update(config.clone());

                Ok(())
            }
            ChangeOp::Update => {
                let config = change
                    .new_config
                    .as_ref()
                    .ok_or_else(|| Error::Config("No new config for update".to_string()))?;

                // Apply the resource update
                self.update_resource(config).await?;

                // Update state
                self.state_manager.update(config.clone());

                Ok(())
            }
            ChangeOp::Delete => {
                // Apply the resource deletion
                self.delete_resource(&change.resource_name, &change.resource_kind)
                    .await?;

                // Update state
                self.state_manager.delete(&change.resource_name);

                Ok(())
            }
            ChangeOp::NoChange => Ok(()),
        }
    }

    async fn create_resource(&self, config: &DeclarativeConfig) -> Result<()> {
        tracing::debug!("Creating {:?}: {}", config.kind, config.metadata.name);
        let (store, applier) = self.applier_for(&config.kind)?;
        applier.upsert_resource(store, config).await
    }

    async fn update_resource(&self, config: &DeclarativeConfig) -> Result<()> {
        tracing::debug!("Updating {:?}: {}", config.kind, config.metadata.name);
        let (store, applier) = self.applier_for(&config.kind)?;
        applier.upsert_resource(store, config).await
    }

    async fn delete_resource(&self, name: &str, kind: &ResourceKind) -> Result<()> {
        tracing::debug!("Deleting {:?}: {}", kind, name);
        let (store, applier) = self.applier_for(kind)?;
        applier.delete_resource(store, kind, name).await
    }

    async fn restore_store(&self, revision: i64) -> Result<()> {
        let (store, _) = self.target()?;
        store.restore_revision(revision, "gitops").await
    }

    /// Rollback to a specific snapshot
    pub async fn rollback_to_snapshot(&mut self, snapshot_id: &str) -> Result<()> {
        let snapshot = self
            .state_manager
            .get_snapshot(snapshot_id)
            .ok_or_else(|| Error::Config(format!("Snapshot not found: {}", snapshot_id)))?;

        tracing::info!(
            "Rolling back to snapshot: {} ({})",
            snapshot.id,
            snapshot.description
        );

        // Apply the snapshot configs (recursive call needs boxing)
        let result = Box::pin(self.apply(snapshot.configs.clone())).await?;

        if !result.success {
            return Err(Error::Config(format!(
                "Rollback failed: {} errors",
                result.errors.len()
            )));
        }

        Ok(())
    }

    /// Get state manager reference
    pub fn state_manager(&self) -> &StateManager {
        &self.state_manager
    }
}

/// Read a GitOps state file: one YAML list (current format) or the old
/// `---`-separated single documents (state written before the fix above).
pub fn parse_state(content: &str) -> Result<Vec<DeclarativeConfig>> {
    if content.trim().is_empty() {
        return Ok(Vec::new());
    }
    if let Ok(v) = serde_yaml::from_str::<Vec<DeclarativeConfig>>(content) {
        return Ok(v);
    }
    let mut out = Vec::new();
    for doc in serde_yaml::Deserializer::from_str(content) {
        let v = serde_yaml::Value::deserialize(doc)
            .map_err(|e| Error::Config(format!("GitOps state: {e}")))?;
        if v.is_null() {
            continue;
        }
        out.push(
            serde_yaml::from_value(v).map_err(|e| Error::Config(format!("GitOps state: {e}")))?,
        );
    }
    Ok(out)
}

/// Pretty-print diff result
pub fn format_diff(diff: &DiffResult) -> String {
    let mut output = String::new();

    output.push_str(&format!(
        "Changes: {} create, {} update, {} delete\n\n",
        diff.creates, diff.updates, diff.deletes
    ));

    for change in &diff.changes {
        let symbol = match change.operation {
            ChangeOp::Create => "+",
            ChangeOp::Update => "~",
            ChangeOp::Delete => "-",
            ChangeOp::NoChange => " ",
        };

        output.push_str(&format!(
            "{} {:?}: {}\n",
            symbol, change.resource_kind, change.resource_name
        ));
    }

    output
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::declarative::*;

    #[tokio::test]
    async fn test_diff_create() {
        let temp_dir = tempfile::tempdir().unwrap();
        let engine = ApplyEngine::new(temp_dir.path().to_path_buf());

        let config = DeclarativeConfig {
            api_version: API_VERSION.to_string(),
            kind: ResourceKind::FirewallRule,
            metadata: Metadata {
                name: "test-rule".to_string(),
                description: None,
                labels: None,
                annotations: None,
            },
            spec: ResourceSpec::FirewallRule(FirewallRuleSpec {
                action: RuleAction::Allow,
                interface: None,
                direction: None,
                source: AddressSpec {
                    address: Some("0.0.0.0/0".to_string()),
                    ports: None,
                    port_ranges: None,
                },
                destination: AddressSpec {
                    address: Some("10.0.0.1".to_string()),
                    ports: Some(vec![80]),
                    port_ranges: None,
                },
                protocol: Some("tcp".to_string()),
                log: false,
                schedule: None,
                gateway: None,
                enabled: true,
            }),
        };

        let diff = engine.diff(&[config]).unwrap();

        assert_eq!(diff.creates, 1);
        assert_eq!(diff.updates, 0);
        assert_eq!(diff.deletes, 0);
    }

    #[tokio::test]
    async fn gitops_state_is_readable_by_the_next_process() {
        let d = tempfile::tempdir().unwrap();
        let yaml = |n: &str| {
            format!(
                "- apiVersion: patronus.firewall/v1\n  kind: FirewallRule\n  metadata:\n    name: {n}\n  spec:\n    action: allow\n    source: {{ address: \"0.0.0.0/0\" }}\n    destination: {{ address: \"192.168.1.10\", ports: [443] }}\n    protocol: tcp\n    enabled: true\n"
            )
        };
        let mut sm = StateManager::new(d.path().to_path_buf());
        sm.init().await.unwrap();
        for n in ["b-rule", "a-rule"] {
            sm.update(ConfigParser::parse_yaml(&yaml(n)).unwrap().remove(0));
        }
        sm.save_current_state().await.unwrap();
        // a new process (the next `patronus gitops sync`) loads it
        let mut again = StateManager::new(d.path().to_path_buf());
        again.init().await.unwrap();
        assert!(again.get("a-rule").is_some() && again.get("b-rule").is_some());
        assert_eq!(again.list().len(), 2);
        // state files written by older versions (--- separated docs) load too
        let old = format!(
            "{}\n---\n{}\n---\n",
            yaml("x").trim_start_matches("- ").replace("\n  ", "\n"),
            yaml("y").trim_start_matches("- ").replace("\n  ", "\n")
        );
        let v = parse_state(&old).unwrap();
        assert_eq!(
            v.iter()
                .map(|c| c.metadata.name.as_str())
                .collect::<Vec<_>>(),
            ["x", "y"]
        );
        assert!(parse_state("").unwrap().is_empty());
    }

    #[test]
    fn test_format_diff() {
        let diff = DiffResult {
            changes: vec![ConfigChange {
                operation: ChangeOp::Create,
                resource_kind: ResourceKind::FirewallRule,
                resource_name: "allow-web".to_string(),
                old_config: None,
                new_config: None,
                dependencies: Vec::new(),
            }],
            creates: 1,
            updates: 0,
            deletes: 0,
            no_changes: 0,
        };

        let formatted = format_diff(&diff);
        assert!(formatted.contains("+ FirewallRule: allow-web"));
    }
}
