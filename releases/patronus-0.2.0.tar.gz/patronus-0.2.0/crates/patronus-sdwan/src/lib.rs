//! Patronus SD-WAN
//!
//! Software-Defined Wide Area Networking for Patronus firewall.
//!
//! # Features
//!
//! - Automatic mesh VPN peering between sites
//! - Real-time path quality monitoring
//! - Intelligent routing based on application requirements
//! - Sub-second failover on path degradation
//! - Load balancing across multiple paths
//!
//! # Architecture
//!
//! ```text
//! ┌─────────────┐    ┌──────────────┐    ┌─────────────┐
//! │   Mesh      │───▶│   Monitor    │───▶│   Routing   │
//! │   Manager   │    │   (Paths)    │    │   Engine    │
//! └─────────────┘    └──────────────┘    └─────────────┘
//!       │                    │                    │
//!       └────────────────────┴────────────────────┘
//!                            │
//!                     ┌──────▼──────┐
//!                     │  Database   │
//!                     └─────────────┘
//! ```

pub mod compression;
pub mod database;
pub mod dataplane;
pub mod dpi;
pub mod edge;
pub mod error;
pub mod export;
pub mod failover;
pub mod health;
pub mod mesh;
pub mod metrics;
pub mod monitor;
pub mod netpolicy;
pub mod peering;
pub mod policy;
pub mod qos;
pub mod routing;
pub mod sla;
pub mod traffic_stats;
pub mod types;

pub use error::{Error, Result};
pub use types::{FlowKey, FlowRecord, FlowStats, PathId, SiteId};

use std::sync::Arc;

/// SD-WAN manager coordinating all components
pub struct SdwanManager {
    mesh: Arc<mesh::MeshManager>,
    monitor: Arc<monitor::PathMonitor>,
    routing: Arc<routing::RoutingEngine>,
    #[allow(dead_code)]
    db: Arc<database::Database>,
}

impl SdwanManager {
    /// Create a new SD-WAN manager
    pub async fn new(config: SdwanConfig) -> Result<Self> {
        let db = Arc::new(database::Database::new(&config.database_path).await?);

        let mesh = Arc::new(
            mesh::MeshManager::new(config.site_id, config.site_name.clone(), db.clone()).await?,
        );

        let monitor = Arc::new(monitor::PathMonitor::new(db.clone()));
        let routing = Arc::new(routing::RoutingEngine::new(db.clone()));

        Ok(Self {
            mesh,
            monitor,
            routing,
            db,
        })
    }

    /// Start the SD-WAN manager
    pub async fn start(&self) -> Result<()> {
        tracing::info!("Starting SD-WAN manager");

        // Start mesh manager (site discovery and peering)
        self.mesh.start().await?;

        // Start path monitoring
        self.monitor.start().await?;

        // Start routing engine
        self.routing.start().await?;

        tracing::info!("SD-WAN manager started successfully");
        Ok(())
    }

    /// Stop the SD-WAN manager
    pub async fn stop(&self) -> Result<()> {
        tracing::info!("Stopping SD-WAN manager");

        self.routing.stop().await?;
        self.monitor.stop().await?;
        self.mesh.stop().await?;

        tracing::info!("SD-WAN manager stopped");
        Ok(())
    }

    /// Get mesh manager
    pub fn mesh(&self) -> &Arc<mesh::MeshManager> {
        &self.mesh
    }

    /// Get path monitor
    pub fn monitor(&self) -> &Arc<monitor::PathMonitor> {
        &self.monitor
    }

    /// Get routing engine
    pub fn routing(&self) -> &Arc<routing::RoutingEngine> {
        &self.routing
    }
}

/// SD-WAN configuration
#[derive(Clone, Debug)]
pub struct SdwanConfig {
    /// Unique site identifier.
    ///
    /// `None` (the default) uses the site ID persisted in the database with
    /// this site's mesh signing key, generating and persisting both on first
    /// start. `Some(id)` seeds a fresh database with that ID; startup fails if
    /// the database already holds a different identity, because peers pin
    /// (trust-on-first-use) the key they first saw for each site ID.
    pub site_id: Option<SiteId>,

    /// Human-readable site name
    pub site_name: String,

    /// Database file path
    pub database_path: String,

    /// Seed sites for bootstrapping
    pub seed_sites: Vec<String>,

    /// Control plane listen address
    pub control_plane_addr: std::net::SocketAddr,
}

impl Default for SdwanConfig {
    fn default() -> Self {
        Self {
            site_id: None,
            site_name: "default-site".to_string(),
            database_path: "/var/lib/patronus/sdwan.db".to_string(),
            seed_sites: Vec::new(),
            control_plane_addr: "0.0.0.0:51821".parse().unwrap(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_sdwan_manager_creation() {
        let config = SdwanConfig {
            database_path: ":memory:".to_string(),
            ..Default::default()
        };

        let manager = SdwanManager::new(config).await;
        assert!(manager.is_ok());
    }
}
