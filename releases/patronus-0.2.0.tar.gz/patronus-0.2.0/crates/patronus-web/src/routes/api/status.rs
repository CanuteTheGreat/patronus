//! System status API endpoints

use crate::state::AppState;
use axum::{
    extract::State,
    http::StatusCode,
    response::{IntoResponse, Response},
    Json,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct SystemStatus {
    pub uptime: u64,
    pub cpu_usage: f64,
    pub memory_usage: f64,
    pub disk_usage: f64,
    pub active_rules: usize,
    /// WireGuard peers with a handshake in the last 180 s + established
    /// IPsec IKE SAs, read live.
    pub vpn_connections: usize,
    /// Why VPN state could not be read (then vpn_connections is a floor).
    pub vpn_errors: Vec<String>,
    pub interfaces: Vec<InterfaceStatus>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct InterfaceStatus {
    pub name: String,
    pub state: String,
    pub rx_bytes: u64,
    pub tx_bytes: u64,
}

/// GET /api/status
pub async fn system_status(State(state): State<AppState>) -> Response {
    let system_info = match state.system.get_info().await {
        Ok(info) => info,
        Err(e) => {
            tracing::error!("Failed to fetch system info: {}", e);
            return (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": "Failed to fetch system info"
                })),
            )
                .into_response();
        }
    };

    let active_rules = state.firewall.count_active_rules().await.unwrap_or(0);
    let vpn = state.vpn.snapshot().await;
    let vpn_connections = vpn.active_connections();
    // Only real read failures (not "tool not installed": then there is no
    // tunnel of that kind to count).
    let vpn_errors = vpn.read_errors();

    let interfaces = match state.interfaces.list_template().await {
        Ok(ifaces) => ifaces
            .into_iter()
            .map(|iface| InterfaceStatus {
                name: iface.name,
                state: iface.state,
                rx_bytes: iface.rx_bytes,
                tx_bytes: iface.tx_bytes,
            })
            .collect(),
        Err(e) => {
            tracing::error!("Failed to fetch interfaces: {}", e);
            vec![]
        }
    };

    let status = SystemStatus {
        uptime: system_info.uptime,
        cpu_usage: system_info.cpu_usage,
        memory_usage: system_info.memory_usage,
        disk_usage: system_info.disk_usage,
        active_rules,
        vpn_connections,
        vpn_errors,
        interfaces,
    };

    Json(status).into_response()
}

/// This lane's API routes, mounted under `/api` by `routes::api_routes`
/// with one `.merge(status::router())` line.
pub fn router() -> axum::Router<AppState> {
    use axum::routing::get;
    axum::Router::new().route("/status", get(system_status))
}
